var e=class extends DetailsModal{constructor(){super(),this.querySelector('input[aria-invalid="true"]')&&this.open({target:this.querySelector("details")})}};customElements.define("password-modal",e);
//# sourceMappingURL=password-modal.js.map
