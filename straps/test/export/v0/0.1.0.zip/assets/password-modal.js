var PasswordModal=class extends DetailsModal{constructor(){super(),this.querySelector('input[aria-invalid="true"]')&&this.open({target:this.querySelector("details")})}};customElements.define("password-modal",PasswordModal);
//# sourceMappingURL=password-modal.js.map
