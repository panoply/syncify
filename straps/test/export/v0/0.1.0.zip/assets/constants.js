var ON_CHANGE_DEBOUNCE_TIMER=300,PUB_SUB_EVENTS={cartUpdate:"cart-update",quantityUpdate:"quantity-update",optionValueSelectionChange:"option-value-selection-change",variantChange:"variant-change",cartError:"cart-error"};
//# sourceMappingURL=constants.js.map
